

def work():
	with open("hello.txt", "w") as f:
	    f.write("I was imported\n")
